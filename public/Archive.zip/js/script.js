    const openNav = () => {
      document.getElementById("mySidenav").style.width = "250px";
    }
    
    const closeNav = () => {
      document.getElementById("mySidenav").style.width = "0";
    }
